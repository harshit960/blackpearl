import WebTorrent from 'webtorrent';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { Upload } from '@aws-sdk/lib-storage';

const s3Client = new S3Client({ region: process.env.AWS_REGIONN });

export const handler = async (event) => {
    const client = new WebTorrent();
    const torrentId = event.torrentId; // The torrent identifier (magnet URL or torrent file URL)
    const bucketName = process.env.BUCKET_NAME; // The name of your S3 bucket

    return new Promise((resolve, reject) => {
        client.add(torrentId, (torrent) => {
            torrent.files.forEach(async (file) => {
                const stream = file.createReadStream();
                const upload = new Upload({
                    client: s3Client,
                    params: {
                        Bucket: bucketName,
                        Key: file.name,
                        Body: stream,
                    },
                });

                try {
                    await upload.done();
                    console.log(`File uploaded successfully: ${file.name}`);
                } catch (err) {
                    console.error(`Error uploading file: ${file.name}`, err);
                    reject(err);
                }
            });

            torrent.on('done', () => {
                console.log('Torrent download complete');
                client.destroy(); // Clean up the WebTorrent client
                resolve('Download and upload complete');
            });
        });
    });
};
